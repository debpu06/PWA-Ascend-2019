define("dojo/_base/query", ["../query", "./NodeList"], function(query){
	// module:
	//		dojo/_base/query

	/*=====
	return {
		// summary:
		//		Deprecated.   Use dojo/query instead.
	};
	=====*/

	return query;
});
