﻿$.expr[":"].contains = $.expr.createPseudo(function (arg) {
    return function (elem) {
        return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
    };
});
function RemoveItemFromList(sf, item) {
    $.ajax({
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        type: 'POST',
        url: '/GenericSettings/RemoveFromList',
        data: JSON.stringify({ 'sf': sf, 'item': item }),
        success: function () {
            //console.log('successfully called.');
        },
        failure: function (response) {
            //console.log('failed called.');
        }
    });
}

function GetValues(obj) {
    var sf = obj.parent().parent().attr('id');
    var item = obj.next().val();
    RemoveItemFromList(sf, item)
    obj.parent().remove();
}

$(document).ready(function () {
    $('#addTagBtn').click(function () {
        $('#tags option:selected').each(function () {
            $(this).appendTo($('#selectedTags'));
        });
    });
    $('#removeTagBtn').click(function () {
        $('#selectedTags option:selected').each(function (el) {
            $(this).appendTo($('#tags'));
        });
    });
    $('.tagRemove').click(function (event) {
        event.preventDefault();
        $(this).parent().remove();
    });

    $('#UpdateGenericSettingsForm').bind("keypress", function (e) {
        if (e.keyCode === 13) return false;
    });

    
   
    EnterFieldType('#field1', '#search-field1');
    EnterFieldType('#field2', '#search-field2');
    EnterFieldType('#field3', '#search-field3');
    EnterFieldType('#field4', '#search-field4');
    EnterFieldType('#field5', '#search-field5');
    EnterFieldType('#field6', '#search-field6');
    EnterFieldType('#field7', '#search-field7');
    function EnterFieldType(id, sf ) {
        $(id+' ul.tags').click(function () {
            $(sf).focus();
        });
        
        $(sf).keypress(function (event) {
            if (event.which === '13') {
                if (($(this).val() !== '') && ($(id + ".tags .addedTag:contains('" + $(this).val() + "') ").length === 0)) {
                    var item = $(this).val();
                    $('<li class="addedTag">' + $(this).val() + '<span class="tagRemove" onclick="GetValues($(this));">x</span><input type="hidden" value="' + $(this).val() + '" name="tags[]"></li>').insertBefore(id + '.tags .tagAdd');
                    $.ajax({
                        contentType: 'application/json; charset=utf-8',
                        dataType: 'json',
                        type: 'POST',
                        url: '/GenericSettings/AddToList',
                        data: JSON.stringify({ 'sf': sf, 'item': item }),
                        success: function () {
                            //console.log('successfully called.');
                        },
                        failure: function (response) {
                            //console.log('failed called.');
                        }
                    }); 
                    $(this).val('');
                } else {
                    $(this).val('');
                }
            }
        });
    }
   
});
