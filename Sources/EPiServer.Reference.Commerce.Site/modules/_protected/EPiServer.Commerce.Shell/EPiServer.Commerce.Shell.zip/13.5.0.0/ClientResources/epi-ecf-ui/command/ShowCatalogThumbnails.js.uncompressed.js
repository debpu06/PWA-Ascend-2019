﻿define("epi-ecf-ui/command/ShowCatalogThumbnails", [
// dojo
    "dojo/_base/declare",
    
// epi-shell
    "epi/shell/command/ToggleCommand",

// Resources
    "epi/i18n!epi/cms/nls/commerce.command.showcatalogthumbnails"
],

function (
// dojo
    declare,

// epi-shell
    ToggleCommand,

// Resources
    res
) {
    // module:
    //      epi-ecf-ui/command/ShowCatalogThumbnails
    // summary:
    //      A command that toggles whether catalog hierarchical list thumbnails are shown.
    // tags:
    //      public

    return declare([ToggleCommand], {

        // property: [public] String
        //      The name of the property on the model which this command will toggle.
        property: "showCatalogThumbnails",

        // category: [readonly] String
        //      A category which provides a hint about how the command could be displayed.
        category: "setting",

        // order: [readonly] Integer
        //      An ordering indication used when generating a ui for this command. 
        //      Commands with order indication will be placed before commands with no order indication.
        order: 10,

        // label: [readonly] String
        //      The action text of the command to be used in visual elements.
        label: res.label
    });
});