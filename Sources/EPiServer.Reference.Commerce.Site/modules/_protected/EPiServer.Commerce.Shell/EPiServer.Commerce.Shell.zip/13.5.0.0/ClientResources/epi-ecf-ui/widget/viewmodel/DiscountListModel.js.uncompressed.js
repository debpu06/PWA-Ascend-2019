﻿define("epi-ecf-ui/widget/viewmodel/DiscountListModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/json",
    "dojo/Evented",
    "dojo/Stateful",
    "dojo/when",
// dojox
    "dojox/mvc/StatefulArray",
// dijit
    "dijit/Destroyable",
// EPi Framework
    "epi",
    "epi/dependency",
    "epi/shell/command/_Command",
// epi-cms
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "../../MarketingUtils",
    "./_MarketingListBaseModel",
    "../../store/Aggressive",
// resources
    "epi/i18n!epi/nls/episerver.shared"
], function (
// dojo
    array,
    declare,
    json,
    Evented,
    Stateful,
    when,
// dojox
    StatefulArray,
// dijit
    Destroyable,
// EPi Framework
    epi,
    dependency,
    _Command,
// epi-cms
    ContentReference,
// epi-ecf-ui
    MarketingUtils,
    _MarketingListBaseModel,
    AggressiveStore,
// resources
    sharedResources
) {
    return declare([_MarketingListBaseModel, Stateful, Evented, Destroyable], {
        // summary:
        //      Represents the discount list widget's model.
        // model:
        //      epi-ecf-ui/widget/viewmodel/DiscountListModel
        // tags:
        //      public

        queryName: "getpromotions",

        typeIdentifiers: [
            MarketingUtils.contentTypeIdentifier.campaignFolder,
            MarketingUtils.contentTypeIdentifier.salesCampaign,
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        // campaignRootFolder: String
        //      The root folder of campaign
        campaignRootFolder: null,

        // _promotionDataStore: [private] dojo.store.api.Store
        //      The epi.commerce.promotions store which provides the ability of saving a list of promotions.
        _promotionDataStore: null,

        // store: [protected] dojo.store.api.Store
        //      The content data store which is used to get promotion data.
        store: null,

        // items: dojox/StatefulArray
        //      The item models array
        items: null,

        // priorityStep: int
        //    The default step of priorities. We want to stretch distance between discount priority values, default is 100,
        //    whichs is retrieved from the MarketingRepositoryDescriptor.
        //    When doing reorder, we have enough room to set new priority values without affecting the other ones.
        //    This can help decrease the number of changes.
        priorityStep: null,

        // hasPendingChanges: Boolean
        //    Holds an indication if the widget's model has modified
        hasPendingChanges: false,

        aggressiveStore: null,

        postscript: function () {
            // summary:
            //      Post properties mixin handler.
            // tags:
            //      protected

            this.inherited(arguments);

            this.items = new StatefulArray();

            this._setupCommands();

            var registry = dependency.resolve("epi.storeregistry");
            this._promotionDataStore = this._promotionDataStore || registry.get("epi.commerce.promotions");

            var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
            this.campaignRootFolder = this.campaignRootFolder || contentRepositoryDescriptors.marketing.roots[0];
            this.priorityStep = this.priorityStep || contentRepositoryDescriptors.marketing.priorityStep;

            if (this.store) {
                var options = {
                    rootId: this.campaignRootFolder,
                    typeIdentifiers: this.typeIdentifiers,
                    includeRoot: true
                };
                this.aggressiveStore = AggressiveStore(this.store, options);

                this.own(this.store.on("delete", this._removeDiscounts.bind(this)));
            }
        },

        onSelectorValueChanged: function (editingItem, selectedItems) {
            var newValue = array.map(selectedItems, function (item) {
                return item.contentLink;
            });
            if (!epi.areEqual(editingItem.properties.excludedItems, newValue)) {
                this._updateExcludedItem(editingItem, newValue);
            }
        },

        save: function () {
            // summary:
            //      Summit priority data.
            // tags:
            //      Protected

            // save modified item only
            var promotions = array.filter(this.items, function (item) {
                return item.hasPendingChanges;
            });
            // construct patch model
            promotions = array.map(promotions, function (item) {
                return {
                    id: item.contentLink,
                    properties: {
                        priority: item.properties.priority,
                        excludedItems: json.toJson(item.properties.excludedItems)
                    }
                };
            });

            var def = this._promotionDataStore.patch({ promotions: promotions }, {});

            // update hasPendingChanges value for saved content, to make sure we will not save them again if it does not change.
            when(def).then(function (results) {
                var hasError = false;

                array.forEach(results, function (result) {
                    if (result.successful) {
                        array.some(this.items, function (item) {
                            if (ContentReference.compareIgnoreVersion(result.savedContentLink, item.contentLink)) {
                                item.hasPendingChanges = false;
                                return true;
                            }
                        }, this);
                    } else {
                        hasError = true;
                    }
                }, this);

                // If has error, keep hasPendingChanges as true, otherwise set to false
                this.set("hasPendingChanges", hasError);

                this.emit("items-saved");
            }.bind(this));

            return def;
        },

        _removeDiscounts: function (removedItem) {
            var indexOfRemovingDiscounts = [];
            this.items.filter(function (discount, index) {
                // In the case removedItem is a discount.
                if (ContentReference.compareIgnoreVersion(discount.contentLink, removedItem.id)) {
                    indexOfRemovingDiscounts.push(index);
                    return true;
                }

                // In the case removedItem is a campaign.
                if (ContentReference.compareIgnoreVersion(discount.parentLink, removedItem.id)) {
                    indexOfRemovingDiscounts.push(index);
                }
            });

            // Order by descending indexes to remove.
            indexOfRemovingDiscounts.sort(function (x, y) {
                return y - x;
            });

            array.forEach(indexOfRemovingDiscounts, function (index) {
                this.items.splice(index, 1);
            }, this);
        },

        _getItemIndex: function (item) {
            // item: [Object]
            //      Promotion data object.
            // tags:
            //      private

            for (var i = 0, length = this.items.length; i < length; i++) {
                if (ContentReference.compareIgnoreVersion(this.items[i].contentLink, item.contentLink)) {
                    return i;
                }
            }
        },

        moveItem: function (item, refItem, before) {
            // summary:
            //      Move an item.
            // item: Object
            //      The current item
            // refItem: Object
            //      The reference item, move to
            // before: Boolean
            //      Indicates that the new item should be moved before the reference index.
            // tags:
            //      Public

            var fromIndex = this._getItemIndex(item);
            item = this.items[fromIndex];
            // remove item first
            this.items.splice(fromIndex, 1);

            // try get the index of reference item, after removed the item
            var toIndex = this._getItemIndex(refItem);
            toIndex = before ? toIndex : toIndex + 1;

            // then re-add item to new index
            this.items.splice(toIndex, 0, item);

            // If moving the item in the same place, should not have changes.
            if (fromIndex === toIndex) {
                return;
            }

            this._normalizePriorityValue(toIndex, true);
            this.set("items", this.items);
            this.set("hasPendingChanges", true);

            this.emit("item-moved");
        },

        _getStatusModel: function (item) {
            return {
                statusLabelKey: this._getStatus(item),
                validFrom: new Date(item.properties.effectiveValidFrom),
                validUntil: new Date(item.properties.effectiveValidUntil)
            };
        },

        _itemsSetter: function (items) {
            // summary:
            //      Sets items array
            // tags:
            //      private

            if (this.items.length === 0) {
                this.items = items;
                return;
            }

            var existingIDs = array.map(this.items, function (item) {
                return item.contentLink;
            });

            for (var i = 0, length = items.length; i < length; i++) {
                var index = existingIDs.indexOf(items[i].contentLink);
                if (index === -1) {
                    this.items.push(items[i]);
                } else {
                    this.items[index] = items[i];
                }
            }
        },

        _itemsGetter: function () {
            // tags:
            //      private

            return this._orderItemsByPriority(this.items);
        },

        _orderItemsByPriority: function (items) {
            // summary:
            //      Order items by the priority
            // tags:
            //      Private

            return items.sort(function (a, b) {
                return a.properties.priority - b.properties.priority;
            });
        },

        _normalizePriorityValue: function (startIndex, isManualMove) {
            // summary:
            //      Normalize priority values for the specific startIndex, and return the priority value (it can be updated if needed).
            // startIndex: int
            //      The start index of algorithm
            // isManualMove: bool
            //      Indicated that item is moving manually.
            // tags:
            //      Private

            var startItem = this.items[isManualMove && startIndex !== 0 ? startIndex - 1 : startIndex];

            if (!startItem) {
                return;
            }

            var currentPriority = startIndex === 0 ? 0 : startItem.properties.priority,
                nextIndex = startIndex + 1;

            if (this.items[nextIndex]) {
                var nextPriority = this.items[nextIndex].properties.priority;

                if (nextPriority <= currentPriority + 1) {
                    // next item(s) need to be adjusted
                    nextPriority = this._normalizePriorityValue(nextIndex, false);
                }

                var midValue = Math.round((currentPriority + nextPriority) / 2);

                return this._setPriority(startIndex, midValue);
            } else {
                // this is the last item and need to be adjusted                    
                return this._setPriority(startIndex, currentPriority + this.priorityStep);
            }
        },

        _setPriority: function (index, priority) {
            // summary:
            //      Set the priority value for item at the specific index.
            // index: int
            //      The index of item to set priority
            // priority: int
            //      The priority value
            // tags:
            //      Private
            if (!this.items[index] || !this.items[index].properties) {
                return;
            }

            this.items[index].properties.priority = priority;
            this.items[index].hasPendingChanges = true;

            return priority;
        },

        _updateExcludedItem: function (editingItem, excludedItems) {
            var some = array.some(this.items, function (i) {
                if (ContentReference.compareIgnoreVersion(i.contentLink, editingItem.contentLink)) {
                    i.properties.excludedItems = excludedItems;
                    i.hasPendingChanges = true;
                    return true;
                }
            });

            if (!some) {
                return;
            }

            this.set("hasPendingChanges", true);
        },

        _setupCommands: function () {
            // summary:
            //      Setup commands for context menu.
            // tags:
            //      private

            // Reset commands list.
            this.commands.length = 0;

            // Move up command
            this._createMoveCommand({
                iconClass: "epi-iconUp",
                label: sharedResources.action.moveup
            }, true);

            // Move down command
            this._createMoveCommand({
                iconClass: "epi-iconDown",
                label: sharedResources.action.movedown
            }, false);
        },

        _createMoveCommand: function (settings, isMoveUp) {
            // summary:
            //      Prepare move command for context menu.
            // settings: Object
            //      Settings of the command
            // isMoveUp: bool
            //      Indicated that the command is moving up
            // tags:
            //      Private

            var self = this,
                command = new _Command({
                    category: "context",
                    iconClass: settings.iconClass,
                    label: settings.label,
                    _onModelChange: function () {
                        var rowIndex = self._getItemIndex(this.model.currentRowItem);
                        // first item can't move up
                        // last item can't move down
                        this.set("canExecute", !!this.get("model") && (isMoveUp ? rowIndex !== 0 : rowIndex < self.items.length - 1));
                    },
                    _execute: function () {
                        var rowIndex = self._getItemIndex(this.model.currentRowItem);
                        // move up : to before previous item
                        // move down : to after next item
                        self.moveItem(this.model.currentRowItem, isMoveUp ? self.items[rowIndex - 1] : self.items[rowIndex + 1], isMoveUp);
                    }
                });

            this.commands.push(command);
        }
    });
});