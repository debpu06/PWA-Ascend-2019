define("epi-ecf-ui/widget/CommandToolbar", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/when",

    // dijit
    "dijit/Toolbar",
    "dijit/layout/_LayoutWidget",

    // epi
    "epi/shell/widget/_AddByDefinition"

], function (
    // dojo
    array,
    declare,
    when,

    // dijit
    Toolbar,
    _LayoutWidget,

    // epi
    _AddByDefinition
) {
        // Important: Mix in _LayoutWidget before Toolbar to get correct CSS classes from Toolbar
        return declare([_LayoutWidget, Toolbar, _AddByDefinition], {

            _commands: null,

            constructor: function (commands) {
                this._commands = commands;
            },

            buildRendering: function () {
                // summary:
                //      Constructs the toolbar container and starts the children setup process.
                // tags:
                //      protected

                this.inherited(arguments);

                // Setup the children items in the toolbar.
                when(this.setupChildren(), function () {
                    this.resize();
                }.bind(this));
            },

            setupChildren: function () {
                // summary:
                //      Setup the items in the toolbar. Inheriting classes should extend this to add more items to the toolbar.
                // tags:
                //      protected

                var toolbarItems = [ 
                    this._createToolbarGroup("clipboard"),
                    this._createToolbarGroup("misc"),
                    this._createToolbarGroup("sorting", { "class" : "dijitInline"})
                ];

                toolbarItems = toolbarItems.concat(array.map(this._commands, function (command, index) {
                    return {
                        name: "command" + index,
                        widgetType: command.buttonType || "epi-ecf-ui/widget/CommandButton",
                        parent: command.toolbarGroup,
                        settings: { model: command, "class": "epi-flat epi-chromeless dijitButton" },
                        title: command.label
                    };
                }));

                return this.add(toolbarItems);
            },

            _createToolbarGroup: function (groupName, groupSettings) {
                return {
                    name: groupName,
                    type: "toolbargroup",
                    parent: "leading",
                    settings: groupSettings || { "class": "epi-groupedButtonContainer dijitInline" }
                };
            }
        });
    }
);