﻿define("epi-ecf-ui/widget/viewmodel/InventoryOverviewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/when",
    "dojo/Stateful",

    // EPi Framework
    "epi/dependency"
], function (
// dojo
    declare,
    when,
    Stateful,
    // EPi Framework
    dependency
) {
    return declare([Stateful], {
        // summary:
        //    Represents the inventory overview widget's model.
        // model:
        //    "epi-ecf-ui/widget/viewmodel/InventoryOverviewModel"
        // tags:
        //    public

        _contentStructureStore: null,

        content: null,

        value: null,

        postscript: function () {
            // summary:
            //      Post properties mixin handler.
            // description:
            //      Set up model and resource for template binding.
            // tags:
            //      protected

            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._contentStructureStore = this._contentStructureStore || registry.get("epi.cms.content.light");
        },

        populateData: function () {
            // summary:
            //      Loads data.
            // tags:
            //      protected
        },

        _valueSetter: function (value) {
            // summary:
            //      Sets value for this widget.

            this.value = value;

            when(this._contentStructureStore.get(value), function (content) {
                this.set("content", content);
            }.bind(this));
        },

        getDefaultItem: function () {
            // summary:
            //      Get default inventory of the current content data.
            // tags:
            //      protected

            return {
                preorderQuantity: 0,
                reorderMinQuantity: 0,
                additionalQuantity: 0,
                backorderAvailableQuantity: 0
            };
        }
    });
});
