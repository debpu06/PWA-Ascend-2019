﻿define("epi-ecf-ui/contentediting/_ViewConfigurationsMixin", [
// dojo
    "dojo/_base/declare",
// epi
    "epi-cms/contentediting/ContentActionSupport"
], function (
// dojo
    declare,
// epi
    ContentActionSupport
) {
    // tags:
    //      internal
    return declare(null, {
        getAuthorizedViews: function (allViews, accessMask) {
            // summary:
            //      Filters views based on the given access mask.
            // tags:
            //      public

            var hasAccess = ContentActionSupport.hasAccess(accessMask, ContentActionSupport.accessLevel.Read | ContentActionSupport.accessLevel.Publish);
            return hasAccess
                ? allViews
                : allViews.filter(function (view) {
                    return ["inventoryview", "pricingview", "relatedentrieseditview", "variantview"].indexOf(view.key) === -1;
                });
        }
    });
});