require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/MonetaryRewardEditor.html':"﻿<div class=\"epi-monetary-reward\">\r\n    <ul class=\"epi-form-container__section\">\r\n        <li class=\"epi-form-container__section__row epi-form-container__section__row--field\">\r\n            <input type=\"radio\"\r\n                   title=\"${resources.percentageradiobuttontooltip}\"\r\n                   data-dojo-type=\"dijit/form/RadioButton\"\r\n                   data-dojo-attach-point=\"usePercentage\"\r\n                   name=\"useAmounts_${id}\"\r\n                   id=\"usePercentage_${id}\" />\r\n            <label for=\"usePercentage_${id}\"\r\n                   title=\"${resources.percentageradiobuttontooltip}\">${resources.usepercentage}</label>\r\n            <div data-dojo-attach-point=\"percentageContainer\" class=\"dijit dijitInline\">\r\n                <div data-dojo-attach-point=\"percentage\"\r\n                     data-dojo-type=\"dijit/form/NumberSpinner\"\r\n                     data-dojo-props=\"constraints: { min: 0, max: 100 }\" />\r\n                title=\"${resources.percentagevaluetooltip}\" />\r\n            </div>\r\n            <span>%</span>\r\n        </li>\r\n\r\n        <li class=\"epi-form-container__section__row epi-form-container__section__row--field\">\r\n            <input type=\"radio\"\r\n                   title=\"${resources.moneylistradiobuttontooltip}\"\r\n                   data-dojo-type=\"dijit/form/RadioButton\"\r\n                   data-dojo-attach-point=\"useAmounts\"\r\n                   name=\"useAmounts_${id}\"\r\n                   id=\"useAmounts_${id}\" />\r\n            <label for=\"useAmounts_${id}\"\r\n                   title=\"${resources.moneylistradiobuttontooltip}\">${resources.useamounts}</label>\r\n            <div data-dojo-attach-point=\"moneyListContainer\" class=\"dijit dijitInline\">\r\n                <div data-dojo-attach-point=\"moneyList\"\r\n                     data-dojo-type=\"epi-ecf-ui/contentediting/editors/MoneyListEditor\" />\r\n            </div>\r\n        </li>\r\n    </ul>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/MonetaryRewardEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-style",
    "dojo/keys",
// dijit
    "dijit/_WidgetBase",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/_TemplatedMixin",
    "dijit/form/NumberSpinner",
    "dijit/form/RadioButton",
// epi
    "epi/shell/widget/_FocusableMixin",
// epi-ecf-ui
    "./MoneyListEditor",
// template
    "dojo/text!./templates/MonetaryRewardEditor.html",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.monetaryreward"
], function (
// dojo
    declare,
    domStyle,
    keys,
// dijit
    _WidgetBase,
    _WidgetsInTemplateMixin,
    _TemplatedMixin,
    NumberSpinner,
    RadioButton,
// epi
    _FocusableMixin,
// epi-ecf-ui
    MoneyListEditor,
// template
    template,
// resources
    resources
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _FocusableMixin], {
        // summary:
        //      The editor used when editing an instance of EPiServer.Commerce.Marketing.MonetaryReward
        // tags:
        //      internal

        templateString: template,

        resources: resources,

        postCreate: function () {
            this.inherited(arguments);
            this.own(
                this.moneyList.on("change", this._onChangeCallback.bind(this)),
                this.percentage.on("change", this._onChangeCallback.bind(this)),
                this.useAmounts.on("change", this._useAmountsChanged.bind(this)),
                this.percentage.on("keydown", this._onPercentageKeyDown.bind(this))
            );
        },

        _onChangeCallback: function () {
            this.onChange(this.get("value"));
        },

        _useAmountsChanged: function (newValue) {
            domStyle.set(this.moneyListContainer, "display", newValue ? "" : "none");
            domStyle.set(this.percentageContainer, "display", newValue ? "none" : "");

            this.percentage.set("required", !newValue);
            this._onChangeCallback();
        },

        _onPercentageKeyDown: function(event){
            if (event.keyCode === keys.ENTER) {
                // Hitting the ENTER key should enable
                // any existing save button on the parent form.
                this.percentage.set("value", this.percentage.get("value"));
            }
        },

        _setValueAttr: function (value) {
            this.moneyList.set("value", value.amounts);
            this.percentage.set("value", value.percentage);
            this.useAmounts.set("checked", value.useAmounts);
            this.usePercentage.set("checked", !value.useAmounts);
        },

        _getValueAttr: function () {
            var useAmounts = this.useAmounts.get("checked");

            if (useAmounts) {
                return {
                    amounts: this.moneyList.get("value"),
                    useAmounts: useAmounts
                };
            }

            return {
                percentage: this.percentage.get("value"),
                useAmounts: useAmounts
            };
        },

        isValid: function () {
            return this.useAmounts.get("checked") ? this.moneyList.isValid() : this.percentage.isValid();
        },

        onChange: function (value) {
            // summary:
            //    Fired when value is changed.
            // tags:
            //    public, callback
        }
    });
});