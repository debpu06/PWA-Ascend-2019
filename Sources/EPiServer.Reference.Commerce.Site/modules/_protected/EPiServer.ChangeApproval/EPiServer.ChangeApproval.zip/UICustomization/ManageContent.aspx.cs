using System;
using System.Linq;
using EPiServer.Core;
using EPiServer.Logging.Compatibility;
using EPiServer.PlugIn;
using EPiServer.Shell.WebForms;
using EPiServer.ServiceLocation;
using EPiServer.DataAbstraction;
using EPiServer.Web;
using EPiServer.Framework.Localization;
using EPiServer.Editor;
using EPiServer.ChangeApproval.UI.Implementation;
using EPiServer.ChangeApproval.UI.Implementation.Internal;
using EPiServer.ChangeApproval.Core.Internal.Command;

namespace EPiServer.ChangeApproval.UI.UICustomization
{
    /// <summary>
    /// Summary description for Moving content.
    /// </summary>
    [GuiPlugIn(DisplayName = "Manage Content", Area = PlugInArea.AdminMenu, UrlFromUi = "admin/managecontent.aspx", LanguagePath = "/admin/managecontent", SortIndex = 300)]
    public partial class ManageContent : ContentWebFormsBase
    {
        private readonly ILog _log = LogManager.GetLogger(typeof(ManageContent));
        internal Injected<MovingCommandService> _movingCommandService;
        internal Injected<LocalizationService> _localizationService;
        internal Injected<ContentRootRepository> ContentRootRepository;
        internal Injected<ISiteDefinitionRepository> SiteDefinitionRepository;
        string message = string.Empty;
        private Injected<ApprovalCommandService> _approvalCommandService;

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            /*
              This code segment is added by ChangeApproval
              If settings of this page have been changed by another person before
               - We will set up a message shown to users explaining why they cannot move this content should be disabled
               - Disable Move to trash button
           */

            // check whether command is associated with a content link and it is in review status
            var approvalCommand = _approvalCommandService.Service.GetCommandByContentReferenceAssociatedWith(CurrentContent.ContentLink);

            if (approvalCommand != null)
            {
                message = GetMessageByCommandType(approvalCommand);
                message += $" {_movingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContentLink.ToReferenceWithoutVersion(), true)}";
                DisableGUIForChangeApproval(message);
            }
            contentDataSource.DataBind();
        }

        private string GetMessageByCommandType(ApprovalCommandBase approvalCommand)
        {
            if (approvalCommand is SecuritySettingCommand)
            {
                return _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/security");
            }

            if (approvalCommand is LanguageSettingCommand)
            {
                return _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/language");
            }

            if (approvalCommand is MovingContentCommand)
            {
                return _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/moving");
            }

            if (approvalCommand is ExpirationDateSettingCommand)
            {
                return _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/expirationdate");
            }

            return _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/general");
        }
        /// <summary>
        /// Manage access right of content
        /// </summary>
        /// <param name="sender">The source of the event</param>
        /// <param name="e">instance containing the event data</param>
        protected void SetAccess(object sender, EventArgs e)
        {
            Response.Redirect("Security.aspx?id=" + CurrentContentLink.ToString());
        }

        /// <summary>
        /// Edit url of the content
        /// </summary>
        protected string EditUrl => UriSupport.AbsoluteUrlFromUIBySettings(PageEditing.GetEditUrl(CurrentContentLink));

        /// <summary>
        /// Delete the content
        /// </summary>
        /// <param name="sender">The source of the event</param>
        /// <param name="e">instance containing the event data</param>
        protected void Delete(object sender, EventArgs e)
        {
            if (IsValidContent(CurrentContentLink))
            {
                var parentLink = CurrentContent.ParentLink;
                try
                {
                    ContentRepository.Delete(CurrentContentLink, true);
                    Response.Redirect("ManageContent.aspx?id=" + parentLink.ToString());
                }
                catch (AccessDeniedException)
                {
                    SystemMessageContainer.SetWarning(LocalizationService.Current.GetString("/admin/managecontent/noaccess"));
                }
            }
        }

        /// <summary>
        /// Move content to trash
        /// </summary>
        /// <param name="sender">The source of the event</param>
        /// <param name="e">instance containing the event data</param>
        protected void MoveToWasteBasket(object sender, EventArgs e)
        {
            if (IsValidContent(CurrentContentLink))
            {
                var parentLink = CurrentContent.ParentLink;
                try
                {
                    ContentRepository.MoveToWastebasket(CurrentContentLink);
                    Response.Redirect("ManageContent.aspx?id=" + parentLink.ToString());
                }
                catch (AccessDeniedException)
                {
                    SystemMessageContainer.SetWarning(LocalizationService.Current.GetString("/admin/managecontent/noaccess"));
                }
                catch (Exception)
                {
                    /*
                      This code segment is added by ChangeApproval
                      If settings of this page have been changed by another person before
                       - We will set up a message shown to users explaining why they cannot move this content should be disabled
                       - Disable Move to trash button
                   */
                    message = _localizationService.Service.GetString("/episerver/changeapproval/interceptui/messagesentforreviewrequest");
                    message += $" {_movingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContent.ContentLink, true)}";
                    DisableGUIForChangeApproval(message);
                }
            }
        }

        private bool IsValidContent(ContentReference contentLink)
        {
            if (ContentReference.IsNullOrEmpty(contentLink))
            {
                SystemMessageContainer.SetWarning(LocalizationService.Current.GetString("/admin/managecontent/nocontent"));
                return false;
            }

            if (SiteDefinitionRepository.Service.List().Any(s => s.StartPage.CompareToIgnoreWorkID(contentLink)))
            {
                SystemMessageContainer.SetWarning(LocalizationService.Current.GetString("/admin/managecontent/startpage"));
                return false;
            }

            if (SiteDefinitionRepository.Service.List().Any(s => s.SiteAssetsRoot.CompareToIgnoreWorkID(contentLink)))
            {
                SystemMessageContainer.SetWarning(LocalizationService.Current.GetString("/admin/managecontent/siteasset"));
                return false;
            }

            if (ContentRootRepository.Service.List().Any(p => p.Value.CompareToIgnoreWorkID(contentLink)))
            {
                SystemMessageContainer.SetWarning(LocalizationService.Current.GetString("/admin/managecontent/contentroot"));
                return false;
            }

            return true;
        }

        /// <summary>
        /// Disable GUI because security settings of the page have been changed by another person before. Refer to PageLoad for more details of this function.
        /// </summary>
        /// <param name="msg"></param>
        private void DisableGUIForChangeApproval(string msg)
        {
            SystemMessageContainer.Message = msg;
            MoveButton.Enabled = false;
        }
    }
}
