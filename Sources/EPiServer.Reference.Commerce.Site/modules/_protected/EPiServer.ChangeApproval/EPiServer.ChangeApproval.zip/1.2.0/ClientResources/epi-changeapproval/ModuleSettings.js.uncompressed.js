define("epi-changeapproval/ModuleSettings", [],
function () {

    // module:
    //      epi-changeapproval/ModuleSettings
    // summary:
    //      Module settings for change approval.
    //      Stores shared settings, constants for entire system.
    // tags:
    //      internal

    return {
        approvalStatus: {
            PENDING: 0,
            ACCEPTED: 1,
            DECLINED: 2,
            CANCELLED: 3
        },

        CommandType: {
            Create : 0,
            Update : 1,
            Delete : 2
        },

        ContentDefinedOnCommandState: {
            Normal: 1,
            Deleting: 2,
            Deleted: 3
        }
    };

});