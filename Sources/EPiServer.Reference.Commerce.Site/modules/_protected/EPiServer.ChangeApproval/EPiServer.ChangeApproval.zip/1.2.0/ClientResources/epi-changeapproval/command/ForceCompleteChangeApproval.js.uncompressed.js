define("epi-changeapproval/command/ForceCompleteChangeApproval", [
    "dojo/_base/declare",
    "./_ChangeApprovalCommand",
    "epi/i18n!epi/cms/nls/episerver.changeapproval.command.forcecomplete"
], function (
    declare,
    _ChangeApprovalCommand,
    localization
) {

    return declare([_ChangeApprovalCommand], {
        // summary:
        //      Approve the current approval
        // tags:
        //      internal

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: localization.label,

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconRight",

        // title [readonly] String
        //      The dialog title
        title: localization.title,

        dialogPlaceHolder: localization.placeholder,

        // dialogText [readonly] String
        //      Text to display above text area
        dialogText: localization.description,

        // confirmationActionText [readonly] String
        //      Approve label for the dialog
        confirmActionText: localization.confirmactiontext,

        // executingLabel: [readonly] String
        //      The executing action text of the command to be used in visual elements.
        executingLabel: localization.label,

        // executeMethod: [readonly] String
        //      The method to execute on the approval service
        executeMethod: "forceCompleteApproval",

        isCommentRequiredPropertyName: "isForcedApproveCommentRequired"
    });
});