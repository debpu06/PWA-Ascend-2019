define("epi-changeapproval/command/ViewChangeDetails", [
    "dojo/_base/declare",
    "dojo/topic",

    // Parent class and mixins
    "epi/shell/command/_Command",

    "epi/i18n!epi/cms/nls/episerver.changeapproval.interceptui"
], function (
    declare,
    topic,

    // Parent class and mixins
    _Command,

    resources
) {

        return declare([_Command], {
            // summary:
            //      Command to display change approval details
            // tags:
            //      internal

            label: resources.changedetaillink,
            tooltip: resources.changedetaillink,
            cssClass: "epi-chromeless epi-visibleLink",

            postscript: function () {
                this.inherited(arguments);
            },

            _onModelChange: function () {
                this.set("canExecute", !!this.model);
            },

            _execute: function () {
                // summary
                //      change context to approval detail
                // tags:
                //      internal

                var contextParameters = { uri: "epi.cms.changeapproval:///" + this.model.approvalID };
                var callerData = {
                    sender: this,
                    forceContextChange: true,
                    forceReload: this.forceReload
                };

                topic.publish("/epi/shell/context/request", contextParameters, callerData);
            }
        });
    });
