define("epi-changeapproval/ChangeApprovalModule", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
// dijit
    "dijit/Destroyable",
// epi
    "epi/_Module",
    "epi/dependency",
    "epi/routes",
    "epi-cms/plugin-area/edit-notifications",
// epi-changeapproval
    "epi-changeapproval/ModuleSettings",
    "epi-changeapproval/commandproviders/ChangeApprovalMenu",
    "epi-changeapproval/ChangeApprovalService",
    "epi-changeapproval/notification/InReviewNotification",
    "epi-changeapproval/widget/ExpirationDialog",
    "epi-changeapproval/viewmodel/ExpirationDialogViewModel",
    // resources
    "epi/i18n!epi/cms/nls/episerver.changeapproval.interceptui"
],
function (
// dojo
    declare,
    lang,
// dijit
    Destroyable,
// epi
    _Module,
    dependency,
    routes,
    EditNotifications,

// epi-addons
    ModuleSettings,
    ChangeApprovalMenuProvider,
    ChangeApprovalService,
    InReviewNotification,
    ExpirationDialog,
    ExpirationDialogViewModel
) {

    return declare([_Module, Destroyable], {
        // module:
        //      epi-changeapproval/changeapprovalmodule
        // summary:
        //      EPiServer ChangeApproval main.
        // tags:
        //      internal

        _settings: null,

        // =======================================================================
        // Public, overrided stubs
        // =======================================================================

        constructor: function (/*Object*/settings) {

            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //      Initialize module
            // tags:
            //      public, extensions

            this.inherited(arguments);

            declare.safeMixin(ModuleSettings, this._settings);

            var registry = this.resolveDependency("epi.storeregistry");
            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

            registry.create("epi-changeapproval.commanddata", this._getRestPath("commanddata"));
            registry.create("epi-changeapproval.commanddetaildata", this._getRestPath("commanddetaildata"));
            registry.create("epi-changeapproval.definition", this._getRestPath("changeapproval-definition"));
            registry.create("epi-changeapproval.changeapproval", this._getRestPath("changeapproval"));

            // Setup the Content Approval service
            this.registerDependency("epi-changeapproval.changeapprovalservice", new ChangeApprovalService());

            // Setup command providers
            var commandregistry = dependency.resolve("epi.globalcommandregistry");
            commandregistry.registerProvider("epi-changeapproval.changeapprovalmenu", new ChangeApprovalMenuProvider());

            var contextService = this.resolveDependency("epi.shell.ContextService");
            contextService.registerRoute("epi.cms.changeapproval", lang.hitch(this, this._redirectContext));

            // Add the constructor function to custom notification
            EditNotifications.add(InReviewNotification);

            var editingCommands = dependency.resolve("epi.cms.contentEditing.command.Editing");
            if (editingCommands && editingCommands.manageExpiration) {
                editingCommands.manageExpiration.expirationDialogClass = ExpirationDialog;
                editingCommands.manageExpiration.expirationDialogViewModelClass = ExpirationDialogViewModel;
            }
        },

        // =======================================================================
        // Private stubs
        // =======================================================================

        _redirectContext: function (/*Object*/context, /*Object*/callerData) {
            // summary:
            //      Redirect context
            // tags:
            //      private

            this._hashWrapper.onContextChange(context, callerData);
        },

        _getRestPath: function (/*String*/name) {
            // summary:
            //      Get EPiServer ChangeApproval REST path
            // name: [String]
            //      The current store name
            // tags:
            //      private

            return routes.getRestPath({
                moduleArea: "EPiServer.ChangeApproval",
                storeName: name
            });
        }
    });
});
